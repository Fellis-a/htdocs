<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label for="inputEmailReg" class="sr-only mt-5">Эл.почта</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="example@mail.ru" required autofocus>
        <label for="inputPasswordReg" class="sr-only">ФИО</label>
        <input type="text" id="inputText" class="form-control" placeholder="Иванов Иван Иванович" required>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Отмена</button>
        <button type="button" class="btn btn-primary">ОТПРАВИТЬ</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/vkr-app/resources/views/registr.blade.php ENDPATH**/ ?>