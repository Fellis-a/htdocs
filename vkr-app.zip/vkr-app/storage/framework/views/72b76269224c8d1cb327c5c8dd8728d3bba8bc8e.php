
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <?php echo $__env->yieldContent('teacherHeader'); ?>

    <!-- Bootstrap core CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">

</head>
<body>
  <?php echo $__env->yieldContent('header'); ?>

    <!-- шапка -->


</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/vkr-app/resources/views/layout/index.blade.php ENDPATH**/ ?>