
<?php $__env->startSection('footer'); ?>
<footer class="pt-4  border-top">
        <div class="d-flex justify-content-start">

             <div class="p-2 bd-highlight ml-5 mr-5">

              <small class="d-block  text-muted">Разработанао центром программной инженирии</small>
              <small class="d-block text-muted">© 2021</small>
            </div>
            <div class="p-2 bd-highlight ml-5 mr-5">

            </div>
          <div class="p-2 bd-highlight ml-5 pl-5">
            <h4>admin@mail.ru</h4>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Написать</a></li>
            </ul>
         </div>

        </div>
      </footer>
<?php /**PATH /Applications/MAMP/htdocs/vkr-app/resources/views/inc/footer.blade.php ENDPATH**/ ?>