<?php $__env->startSection('homeHeader'); ?>
<title>Главная</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('homeTitle'); ?>
<h2>Список ВКР</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/vkr-app/resources/views/home.blade.php ENDPATH**/ ?>