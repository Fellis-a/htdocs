@section('searcher')

<form class="form-inline mt-2 mt-md-4">
            <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submitSearch">Search</button>
          </form>
