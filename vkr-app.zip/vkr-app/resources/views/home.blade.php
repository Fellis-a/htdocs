@extends('index')

@section('homeHeader')
<title>Главная</title>
@endsection

@section('homeTitle')
<h2>Список ВКР</h2>
@endsection
