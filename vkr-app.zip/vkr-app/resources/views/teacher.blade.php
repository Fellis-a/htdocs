@extends('index')

@section('teacherHeader')
<title>Личный кабинет</title>
@endsection

@section('teacherTitle')
<h2>Мои ВКР</h2>
@endsection
